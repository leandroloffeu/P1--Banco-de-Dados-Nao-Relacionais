// src/repositories/userRepository.js
const UserModel = require('../models/userModel');

class UserRepository {
  async createUser(username, password) {
    const user = new UserModel({ username, password });
    await user.save();
    return user;
  }

  async findUserByUsername(username) {
    return UserModel.findOne({ username });
  }
}

module.exports = new UserRepository();
