// src/controllers/userController.js
const userRepository = require('../repositories/userRepository');

class UserController {
  async registerUser(req, res) {
    try {
      const { username, password } = req.body;
      const existingUser = await userRepository.findUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ message: 'Username already exists' });
      }
      const newUser = await userRepository.createUser(username, password);
      return res.status(201).json(newUser);
    } catch (error) {
      console.error('Error registering user:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  }

  // Implement login and logout methods here
}

module.exports = new UserController();
