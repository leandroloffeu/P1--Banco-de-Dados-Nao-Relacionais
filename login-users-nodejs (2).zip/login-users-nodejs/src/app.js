import express from 'express'
import conexaoPromise from '../infra/conexao.js';

const app = express();

app.use(express.json());

(async () => {
  try {
    await conexaoPromise;
    console.log('Connected to MongoDB');
    // You can start using your MongoDB connection here
  } catch (error) {
    console.error('Error connecting to MongoDB:', error);
  }
})

app.get('/', (req, res) => {
  res.send('Ola Mundo!')
})

export default app;
