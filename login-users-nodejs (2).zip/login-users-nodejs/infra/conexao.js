import mongoose from 'mongoose';

const conexaoPromise = mongoose.connect('mongodb://localhost/login_users_db', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

export default conexaoPromise;